<script>
import FullCalendar from '@fullcalendar/vue'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin, { Draggable } from '@fullcalendar/interaction'
import esLocale from '@fullcalendar/core/locales/es'


export default {
  components: {
    FullCalendar
  },
  data() {
    return {
      selectedDate: null,
      selectedAppointment: null,
      appointments: [
        {
          id: 1,
          final_date: '2024-03-15',
          start_date: '2024-03-15',
          status: 'Confirmada',
          comments:'La cita es por dolor de espalda',
          doctor: {
            id: 101,
            name: 'Dr. Juan Pérez'
          },
          patient: {
            id: 201,
            name: 'Laura Rodríguez'
          }
        },
         {
          id: 2,
          final_date: '2024-03-15',
          start_date: '2024-03-15',
          status: 'Pendiente',
          comments:'La cita es por dolor de huevo',
          doctor: {
            id: 102,
            name: 'Dra. María González'
          },
          patient: {
            id: 202,
            name: 'Roberto Fernández'
          }
        },
        {
          id: 3,
          final_date: '2024-03-17T12:00:00',
          start_date: '2024-03-17T11:00:00',
          status: 'Cancelada',
          comments:'La cita es por dolor de obo',
          doctor: {
            id: 103,
            name: 'Dr. Carlos López'
          },
          patient: {
            id: 203,
            name: 'Lucía Gómez'
          }
        },
        {
          id: 4,
          final_date: '2024-03-18T13:00:00',
          start_date: '2024-03-18T12:00:00',
          status: 'Confirmada',
          comments:'La cita es por dolor de piruli',
          doctor: {
            id: 104,
            name: 'Dra. Ana Martínez'
          },
          patient: {
            id: 204,
            name: 'Diego Díaz'
          }
        },
        {
          id: 5,
          final_date: '2024-03-19T14:00:00',
          start_date: '2024-03-19T13:00:00',
          status: 'Confirmada',
          comments:'La cita es por dolor de melox',
          doctor: {
            id: 105,
            name: 'Dr. José Sánchez'
          },
          patient: {
            id: 205,
            name: 'Sofía Hernández'
          }
        }
      ]
    }
  },
  computed: {
    calendarOptions() {
      return {
        plugins: [
          dayGridPlugin,
          interactionPlugin
        ],
        headerToolbar: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,dayGridWeek'
        },
        initialView: 'dayGridMonth',
        selectable: true,
        dateClick: this.handleDateClick,
        events: this.appointments.map(appointment => ({
          title: appointment.patient.name,
          start: appointment.start_date,
          end: appointment.final_date,
          backgroundColor: this.getBackgroundColor(appointment.status),
          extendedProps: {
            appointment
          },
          
        })),
        locale: esLocale
      }
    }
  },
  methods: {
    handleDateClick(info) {
  this.selectedDate = info.dateStr;
  console.log("Se muestra un modal" + this.selectedDate)
  // Verificar si info.event tiene la propiedad extendedProps
  if (info.event && info.event.extendedProps) {
    console.log("Se muestra un modal" + info)
    this.selectedAppointment = info.event.extendedProps.appointment; 
    this.$nextTick(() => {
     
      this.$refs.modal.show();
    });
  }
},
    getBackgroundColor(status) {
      switch (status) {
        case 'Confirmada':
          return 'green';
        case 'Pendiente':
          return 'orange';
        case 'Cancelada':
          return 'red';
        default:
          return 'blue';
      }
    },
    renderEventContent(eventInfo) {
      const appointment = eventInfo.event.extendedProps.appointment;
      const button = document.createElement('button');
      button.classList.add('fc-button');
      button.textContent = appointment.patient.name;
      button.style.backgroundColor = eventInfo.backgroundColor;
      button.style.color = eventInfo.textColor;
      button.style.borderColor = eventInfo.borderColor;
      button.addEventListener('click', () => {
        // Aquí puedes manejar el clic en el botón del evento
        console.log(appointment);
        // Aquí puedes abrir un modal u otra acción según tu necesidad
        this.selectedAppointment = appointment;
        this.$refs.modal.show();
      });
      return { domNodes: [button] };
      }
  }
};
</script>

<template>
  <div class='demo-app'>
    
    <div class='demo-app-main'>
      <FullCalendar
        class='demo-app-calendar'
        :options='calendarOptions'
      >
      </FullCalendar>
    </div>
    <b-modal ref="modal" title="Detalles de la cita" hide-footer>
      <div v-if="selectedAppointment">
    <p><strong>Fecha:</strong> {{ selectedAppointment.start }}</p>
    <p><strong>Paciente:</strong> {{ selectedAppointment.patient.name }}</p>
    <p><strong>Doctor:</strong> {{ selectedAppointment.doctor.name }}</p>
    <p><strong>Estado:</strong> {{ selectedAppointment.status }}</p>
    <p><strong>Comentarios:</strong> {{ selectedAppointment.comments }}</p>
  </div>
    </b-modal>
  </div>
</template>

<style lang='css'>

h2 {
  margin: 0;
  font-size: 16px;
}

ul {
  margin: 0;
  padding: 0 0 0 1.5em;
}

li {
  margin: 1.5em 0;
  padding: 0;
}

b { /* used for event dates/times */
  margin-right: 3px;
}

.demo-app {
  display: flex;
  max-height: 600px;
  max-width: 100%;
  font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
  font-size: 14px;
  background-color: rgb(251, 253, 255);
  border-radius: 10px;
  border: solid rgb(238, 238, 238);
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.108);
}


.demo-app-main {
  flex-grow: 1;
  padding: 3em;
  
 
}
@media screen and (max-width: 600px) {
  .fc-toolbar-title, .fc-toolbar-chunk {
    display: none;
  }
  .fc-toolbar-center {
    text-align: center;
  }
  .fc-toolbar.fc-header-toolbar {
    flex-wrap: wrap;
  }
}

.fc { /* the calendar root */
  max-width: 89%;
  border-radius: 10px;
  padding: 10px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.108);
  background-color: white;
  margin: 0 auto;
  max-height: 100%;
}

</style>
