<template>
    <b-container fluid>
        <div class="rowCointainer"></div>
        <b-container  class="bv-example-row">

          <b-row class="text-center">
                <b-col md> 
                    <b-img thumbnail shadow rounded="circle"  style="background-color: blue; max-height: 200px; margin-top: -80px;" fluid src="https://picsum.photos/250/250/?image=58" alt="Image 2"></b-img>
                </b-col>    
                <b-col md ><h3 style="margin-top: 26px;">Zuriel Rios Aguilar</h3></b-col>
                <b-col md ><h5 class="mt-4 mb-3">Especialidad:</h5><strong >Medico Urgenciologo</strong></b-col>
                <b-col md ><h5 class="mt-4 mb-3">Cédula Profesional:</h5><strong >HMSS010101DA</strong></b-col>
                <b-col md ><h5 class="mt-4 mb-3">Rating Total: </h5><b-rating  
            value="5"
            variant="warning" 
            readonly 
            no-border
            precision="1"
            size="md"
            
            ></b-rating>  </b-col>                                                                
         </b-row>
         <b-row> <hr class="my-4"> </b-row>
         
         <b-row cols="0">

          <b-tabs pills card class="tabs">
                <b-tab v-for="(tab, index) in tabs" :key="index" :title="tab" @click="emit(tab)"></b-tab>
            </b-tabs>

         </b-row>
        </b-container>    
    </b-container>
    
    
  
</template>

<script>
export default { 
    data() {
      return {
        user: {
          id: 1,
          email: "20213tn042@utez.edu.mx",
          first_surname: "Santander",
          name: "Omar de Jesus",
          password: "$2a$10$guSF3YkYTLX2JHjmXjH0K.sVzZxAv1GTFDg8jWTN2xERBJUdNAlPO",
          phone: "7775196369",
          second_surname: "Verdayes",
          id_rol: 2,
          id_status: 1
        },
        tabs: []
      };
    },
    mounted() {
      this.genUserTabs(this.user.id_rol);
    }, 
    methods: {
      genUserTabs(rol) {
        switch (rol) {
          case 1:
            this.tabs = ["Admin",  "Citas", "Paquetes"];
            break;
          case 2:
            this.tabs = ["Citas", "Comentarios", "Citas Pendientes"];
            break;
          case 3:
            this.tabs = ["Generar Cita", "Mi información"];
            break;
          default:
            this.tabs = [];
            break;
        }
      },
      emit(tab){
        console.log("Mi tab desde user..."+tab)
        this.$emit('sendData', tab);
      }
  }
  }
</script>

<style>
.rowCointainer{ 
    background:linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(59, 59, 59, 0.5)), 
                url('../../assets/clinica-angeles1.jpg');
    background-size: cover;
    background-position: center;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
    border-radius: 10px;
    min-height: 200px;
    height:  400px;
    padding: 20px;
    margin: -100px 20px 20px 20px;
    
}

.doctorAvatar{
    width: 180px;
    height: 180px;
    overflow: hidden;
    margin-top:-30px;
  }
.tabs{
    margin-top: -1%;
    display: grid;
    grid-template-columns: auto;
    gap: 10px;
    justify-content: end;
    
}
</style>