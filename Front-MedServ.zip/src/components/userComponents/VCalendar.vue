<template>
  <b-container fluid>
    <b-row><h3>Citas Programadas</h3></b-row>

    <b-row class="mb-3">
      <b-col>
        <vc-date-picker v-model="date">
            <template v-slot="{ inputValue}">
              <input
                class="bg-white border px-2 py-1 rounded"
                :value="inputValue"
                type="date"
                
              />
            </template>
        </vc-date-picker>
      </b-col>
      
      <b-col>
        <input type="text" v-model="searchPatient" placeholder="Buscar por paciente">
      </b-col>
    </b-row>
    

    <vc-calendar is-expanded :attributes='attributes' locale="ES" :masks="masks"  @clickDate="handleDateClick">
     
    </vc-calendar>

  </b-container>
    
  </template>
  
  <script>
  export default {
    data() {
        return {
          masks: {
            weekdays: 'WWW',
            dayPopover: 'WWW, MMMM D, YYYY',
          },
      appointments: [
        {
          id: 1,
          final_date: '2024-03-15',
          start_date: '2024-03-15',
          status: 'Confirmada',
          comments:'La cita es por dolor de espalda',
          doctor: {
            id: 101,
            name: 'Dr. Juan Pérez'
          },
          patient: {
            id: 201,
            name: 'Laura Rodríguez'
          }
        },
        {
          id: 2,
          final_date: '2024-03-16T11:00:00',
          start_date: '2024-03-16T10:00:00',
          status: 'Pendiente',
          comments:'La cita es por dolor de huevo',
          doctor: {
            id: 102,
            name: 'Dra. María González'
          },
          patient: {
            id: 202,
            name: 'Roberto Fernández'
          }
        },
        {
          id: 3,
          final_date: '2024-03-17T12:00:00',
          start_date: '2024-03-17T11:00:00',
          status: 'Cancelada',
          comments:'La cita es por dolor de obo',
          doctor: {
            id: 103,
            name: 'Dr. Carlos López'
          },
          patient: {
            id: 203,
            name: 'Lucía Gómez'
          }
        },
        {
          id: 4,
          final_date: '2024-03-18T13:00:00',
          start_date: '2024-03-18T12:00:00',
          status: 'Confirmada',
          comments:'La cita es por dolor de piruli',
          doctor: {
            id: 104,
            name: 'Dra. Ana Martínez'
          },
          patient: {
            id: 204,
            name: 'Diego Díaz'
          }
        },
        {
          id: 5,
          final_date: '2024-03-19T14:00:00',
          start_date: '2024-03-19T13:00:00',
          status: 'Confirmada',
          comments:'La cita es por dolor de melox',
          doctor: {
            id: 105,
            name: 'Dr. José Sánchez'
          },
          patient: {
            id: 205,
            name: 'Sofía Hernández'
          }
        }
      ],
      selectDate: ''
    };
  },
  computed: {
    attributes() {
  return this.appointments.map(appointment => {
    let highlightColor = 'blue';
    if (appointment.status === 'Confirmada') {
      highlightColor = 'green'; 
    } else if (appointment.status === 'Proceso') {
      highlightColor = 'orange';
    } else if (appointment.status === 'Cancelada') {
      highlightColor = 'red'; 
    }
    
    return {
      dates: appointment.start_date,
      highlight: {
        color: highlightColor,
        fillMode: 'solid',
        contentClass: 'italic',
      },
      popover: {
        label: 'Paciente: ' + appointment.patient.name + '\nEstado: ' + appointment.status,
       
      },
      customData: appointment
    };
  });
}
  },
  methods: {
    handleDateClick(date) {
      console.log("asdhasjd")
      this.selectedDate = date;
      this.$refs.modal.show();
    }
  },
};
</script>

<style >

</style>