<template>
  <b-container>

          <!-- Generar las cards de doctores -->
    <b-row v-if="tableInfo==='Doctores'">
      <b-col  
        
        v-for="(item,index) in tableItems" :key="index"   
        class="justify-content-md-center mb-4" 
        sm="6"   
        md="3"
      >
        <b-card
          img-src="https://picsum.photos/600/300/?image=25"
          img-alt="Image"
          img-top
          no-body
        >
          <b-card-body>
            <b-card-title>{{item.name}} {{ item.lastname }}</b-card-title>
            <b-card-sub-title class="mb-2">{{item.speciality}}</b-card-sub-title>
            <hr class="my-4"> 
            <b-card-text>
               <strong>Cédula profesional: </strong> {{ item.professional_id }}
            </b-card-text>
            <b-card-text style="font-size: .9rem;"> 
                {{ item.email }}
            </b-card-text>
            <b-form-rating  
              v-model="item.rating" 
              variant="warning" 
              readonly 
              show-value
              show-value-max
              precision="1"
              size="md"
            ></b-form-rating>
          </b-card-body>
          <b-card-body>
            <b-button-group style="gap: 10px; max-height: 40px;" class="col">
              <!-- Agrega el método para abrir el modal -->
              <b-button @click="openModal(item)" variant="outline-warning">
                <b-icon icon="pencil-fill"></b-icon> Editar
              </b-button>
              <b-button variant="outline-danger">
                <b-icon icon="x-square-fill"></b-icon> Eliminar
              </b-button>
            </b-button-group>
          </b-card-body>
        </b-card>
      </b-col>

    </b-row>
    

        <!-- Generar las cards de doctores -->
    <b-row v-if="tableInfo==='Pacientes'">
      <b-col  
        
        v-for="(item,index) in tableItems" :key="index"   
        class="justify-content-md-center mb-4" 
        sm="6"   
        md="3"
      >
        <b-card
          img-src="https://picsum.photos/600/300/?image=25"
          img-alt="Image"
          img-top
          no-body
        >
          <b-card-body>
            <b-card-title>{{item.name}} {{ item.lastname }}</b-card-title>
            <b-card-sub-title class="mb-2"></b-card-sub-title>
            <hr class="my-4">
            <b-card-text>
               <strong>Enfermedades: </strong> {{ item.issues }}
            </b-card-text> 
            <b-card-text>
               <strong>Alergias: </strong> {{ item.alerggies }}
            </b-card-text>
            <b-card-text style="font-size: .9rem;"> 
              <strong>Email: </strong>  {{ item.email }}
            </b-card-text>
          </b-card-body>
          <b-card-body>
            <b-button-group style="gap: 10px; max-height: 40px;" class="col">
              <!-- Agrega el método para abrir el modal -->
              <b-button @click="openModal(item)" variant="outline-warning">
                <b-icon icon="pencil-fill"></b-icon> Editar
              </b-button>
              <b-button variant="outline-danger">
                <b-icon icon="x-square-fill"></b-icon> Eliminar
              </b-button>
            </b-button-group>
          </b-card-body>
        </b-card>
      </b-col>

    </b-row>

    <b-row v-if="tableInfo==='Servicios'">
      <b-col
        v-for="(item,index) in tableItems" :key="index"   
        class="justify-content-md-center mb-4" 
        sm="6"   
        md="3"
      >
        <b-card
          img-src="https://picsum.photos/600/300/?image=25"
          img-alt="Image"
          img-top
          no-body
        >
          <b-card-body>
            <b-card-title>{{item.title}} </b-card-title>
            <b-card-sub-title class="mb-2"></b-card-sub-title>
            <hr class="my-4">
            <b-card-text>
               <strong>Descripción: </strong> {{ item.description }}
            </b-card-text> 
            <b-card-text>
               <strong>Precio: </strong> {{ item.price }}
            </b-card-text>
            <b-card-text style="font-size: .9rem;"> 
              <strong>Especialidad: </strong>  {{ item.speciality }}
            </b-card-text>
          </b-card-body>
          <b-card-body>
            <b-button-group style="gap: 10px; max-height: 40px;" class="col">
              <!-- Agrega el método para abrir el modal -->
              <b-button @click="openModal(item)" variant="outline-warning">
                <b-icon icon="pencil-fill"></b-icon> Editar
              </b-button>
              <b-button variant="outline-danger">
                <b-icon icon="x-square-fill"></b-icon> Eliminar
              </b-button>
            </b-button-group>
          </b-card-body>
        </b-card>
      </b-col>

    </b-row>

<b-row v-if="tableInfo==='Especialidades'">
  <b-table striped hover :items="specialties" :fields="specialtyFields">
    <template v-slot:cell(actions)="data">
      <b-button @click="editSpecialty(data.item)" variant="outline-warning">
        <b-icon icon="pencil-fill"></b-icon> Editar
      </b-button>
      <b-button @click="deleteSpecialty(data.item)" variant="outline-danger">
        <b-icon icon="x-square-fill"></b-icon> Eliminar
      </b-button>
    </template>
  </b-table>
</b-row>




    <!-- Modal para mostrar los detalles del doctor -->
    <b-modal ref="modal" title="Editar Información Doctor" hide-footer>
      <b-form @submit.prevent="confirmEdit">
        <b-form-group label="Nombre">
          <b-form-input v-model="editedItem.name"></b-form-input>
        </b-form-group>
        <b-form-group label="Apellido">
          <b-form-input v-model="editedItem.lastname"></b-form-input>
        </b-form-group>
        <b-form-group label="Especialidad">
          <b-form-input v-model="editedItem.speciality"></b-form-input>
        </b-form-group>
        <b-form-group label="Cédula profesional">
          <b-form-input v-model="editedItem.professional_id"></b-form-input>
        </b-form-group>
        <b-form-group label="Email">
          <b-form-input v-model="editedItem.email"></b-form-input>
        </b-form-group>
        <b-button type="submit" variant="primary">Confirmar</b-button>
        <b-button @click="closeModal" variant="secondary">Cancelar</b-button>
      </b-form>
    </b-modal>

    <!-- Modal para mostrar los detalles del doctor -->
    <b-modal ref="modal" title="Editar Información Paciente" hide-footer>
      <b-form @submit.prevent="confirmEdit">
        <b-form-group label="Nombre">
          <b-form-input v-model="editedItem.name"></b-form-input>
        </b-form-group>
        <b-form-group label="Apellido">
          <b-form-input v-model="editedItem.lastname"></b-form-input>
        </b-form-group>
        <b-form-group label="Enfermedades">
          <b-form-input v-model="editedItem.issues"></b-form-input>
        </b-form-group>
        <b-form-group label="Alergias">
          <b-form-input v-model="editedItem.alerggies"></b-form-input>
        </b-form-group>
        <b-form-group label="Email">
          <b-form-input v-model="editedItem.email"></b-form-input>
        </b-form-group>
        <b-button type="submit" variant="primary" class="mt-3">Confirmar</b-button>
        
        <b-button @click="closeModal" class="mt-3"  variant="secondary">Cancelar</b-button>
      </b-form>
    </b-modal>

  </b-container>
</template>

<script>
export default {
    props:{
        tableInfo: {
            type: String, 
            default: "Doctores"
        }

        
    },
        
    data(){
        return{
            fieldsDoctor:  [{key:'name',label:'Nombre'},{key:'lastname',label:'Apellido'},{key:'email',label:'Email'},{key:'professional_id',label:'Cédula'},{key:'speciality',label:'Especialidad'},'Rating'],
            fieldsClient:  [{key:'name',label:'Nombre'},{key:'lastname',label:'Apellido'},{key:'email',label:'Email'},{key:'issues',label:'Enfermedades'},{key:'alerggies',label:'Alergias'},{key:'age', label:'Edad'}, {key:'phone', label:'Teléfono'}],
            fieldsService: [{key:'title',label:'Título'},{key:'description',label:'Descripción'},{key:'price',label:'Precio'},'area',{key:'speciality',label:'Especialidad'}],
            
            
            itemDoctor: [
                { name: 'Juan', lastname: 'Pérez', email: 'juanperez@example.com', professional_id: '123456', speciality: 'Cardiología', rating: 4.5 },
                { name: 'María', lastname: 'González', email: 'mariagonzalez@example.com', professional_id: '789012', speciality: 'Dermatología', rating: 4.8 },
                { name: 'Carlos', lastname: 'López', email: 'carloslopez@example.com', professional_id: '345678', speciality: 'Pediatría', rating: 4.2 },
                { name: 'Ana', lastname: 'Martínez', email: 'anamartinez@example.com', professional_id: '901234', speciality: 'Ginecología', rating: 4.6 },
                { name: 'José', lastname: 'Sánchez', email: 'josesanchez@example.com', professional_id: '567890', speciality: 'Oftalmología', rating: 4.4 }
            ],

            itemsClient: [
                { name: 'Laura', lastname: 'Rodríguez', email: 'laurarodriguez@example.com', issues: 'Hipertensión', alerggies: 'Penicilina', age: 45, phone: '123-456-7890' },
                { name: 'Roberto', lastname: 'Fernández', email: 'robertofernandez@example.com', issues: 'Diabetes', alerggies: 'Ninguna', age: 35, phone: '456-789-0123' },
                { name: 'Lucía', lastname: 'Gómez', email: 'luciagomez@example.com', issues: 'Asma', alerggies: 'Polen', age: 28, phone: '789-012-3456' },
                { name: 'Diego', lastname: 'Díaz', email: 'diegodiaz@example.com', issues: 'Artritis', alerggies: 'Ninguna', age: 50, phone: '012-345-6789' },
                { name: 'Sofía', lastname: 'Hernández', email: 'sofiahernandez@example.com', issues: 'Migrañas', alerggies: 'Ninguna', age: 40, phone: '345-678-9012' }
            ],

            itemsService: [
                { title: 'Consulta médica', description: 'Consulta general con un médico', price: 50, area: 'Medicina general', speciality: 'Medicina general' },
                { title: 'Limpieza dental', description: 'Limpieza y profilaxis dental', price: 80, area: 'Odontología', speciality: 'Odontología' },
                { title: 'Masaje terapéutico', description: 'Masaje relajante y terapéutico', price: 60, area: 'Fisioterapia', speciality: 'Fisioterapia' },
                { title: 'Examen de sangre', description: 'Análisis de sangre completo', price: 100, area: 'Laboratorio', speciality: 'Laboratorio clínico' },
                { title: 'Ecografía abdominal', description: 'Ecografía abdominal y diagnóstico', price: 120, area: 'Imágenes médicas', speciality: 'Radiología' }
            ],
            editedItem: '',
                    }
                },

        computed: {
            
            tableItems() {
            switch (this.tableInfo) {
                case "Doctores":
                return this.itemDoctor;
                case "Pacientes":
                  
                return this.itemsClient;
                case "Servicios":
                return this.itemsService;
                default:
                return [];
            }
            }
  },
  methods: {
    openModal(item) {
      this.editedItem = item;
      this.$refs.modal.show();
    },
    closeModal() {
      this.editedItem = null;
      this.$refs.modal.hide();
    }
  }
};
                
</script>

<style>

</style>