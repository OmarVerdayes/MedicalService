<template>
  <div>

    
    <b-table
        v-if="tableInfo === 'Doctores'"
        hover
        :items="itemDoctor"
        :fields="fieldsDoctor"
        responsive="sm"
        head-variant="light"
      ></b-table>

      <b-table
        v-if="tableInfo === 'Pacientes'"
        hover
        :items="itemsClient"
        :fields="fieldsClient"
        responsive="sm"
        head-variant="light"
      ></b-table>

    
      <b-table
        v-if="tableInfo === 'Servicios'"
        hover
        :items="itemsService"
        :fields="fieldsService"
        responsive="sm"
        head-variant="light"
      ></b-table>
      
  </div>
</template>

<script>
export default {
    props:{
        tableInfo: {
            type: String, 
            default: "Doctores"
        }

        
    },
        
    data(){
        return{
            fieldsDoctor:  [{key:'name',label:'Nombre'},{key:'lastname',label:'Apellido'},{key:'email',label:'Email'},{key:'professional_id',label:'Cédula'},{key:'speciality',label:'Especialidad'},'Rating'],
            fieldsClient:  [{key:'name',label:'Nombre'},{key:'lastname',label:'Apellido'},{key:'email',label:'Email'},{key:'issues',label:'Enfermedades'},{key:'alerggies',label:'Alergias'},{key:'age', label:'Edad'}, {key:'phone', label:'Teléfono'}],
            fieldsService: [{key:'title',label:'Título'},{key:'description',label:'Descripción'},{key:'price',label:'Precio'},'area',{key:'speciality',label:'Especialidad'}],
            
            
            itemDoctor: [
    { name: 'Juan', lastname: 'Pérez', email: 'juanperez@example.com', professional_id: '123456', speciality: 'Cardiología', rating: 4.5 },
    { name: 'María', lastname: 'González', email: 'mariagonzalez@example.com', professional_id: '789012', speciality: 'Dermatología', rating: 4.8 },
    { name: 'Carlos', lastname: 'López', email: 'carloslopez@example.com', professional_id: '345678', speciality: 'Pediatría', rating: 4.2 },
    { name: 'Ana', lastname: 'Martínez', email: 'anamartinez@example.com', professional_id: '901234', speciality: 'Ginecología', rating: 4.6 },
    { name: 'José', lastname: 'Sánchez', email: 'josesanchez@example.com', professional_id: '567890', speciality: 'Oftalmología', rating: 4.4 }
],

itemsClient: [
    { name: 'Laura', lastname: 'Rodríguez', email: 'laurarodriguez@example.com', issues: 'Hipertensión', alerggies: 'Penicilina', age: 45, phone: '123-456-7890' },
    { name: 'Roberto', lastname: 'Fernández', email: 'robertofernandez@example.com', issues: 'Diabetes', alerggies: 'Ninguna', age: 35, phone: '456-789-0123' },
    { name: 'Lucía', lastname: 'Gómez', email: 'luciagomez@example.com', issues: 'Asma', alerggies: 'Polen', age: 28, phone: '789-012-3456' },
    { name: 'Diego', lastname: 'Díaz', email: 'diegodiaz@example.com', issues: 'Artritis', alerggies: 'Ninguna', age: 50, phone: '012-345-6789' },
    { name: 'Sofía', lastname: 'Hernández', email: 'sofiahernandez@example.com', issues: 'Migrañas', alerggies: 'Ninguna', age: 40, phone: '345-678-9012' }
],

itemsService: [
    { title: 'Consulta médica', description: 'Consulta general con un médico', price: 50, area: 'Medicina general', speciality: 'Medicina general' },
    { title: 'Limpieza dental', description: 'Limpieza y profilaxis dental', price: 80, area: 'Odontología', speciality: 'Odontología' },
    { title: 'Masaje terapéutico', description: 'Masaje relajante y terapéutico', price: 60, area: 'Fisioterapia', speciality: 'Fisioterapia' },
    { title: 'Examen de sangre', description: 'Análisis de sangre completo', price: 100, area: 'Laboratorio', speciality: 'Laboratorio clínico' },
    { title: 'Ecografía abdominal', description: 'Ecografía abdominal y diagnóstico', price: 120, area: 'Imágenes médicas', speciality: 'Radiología' }
],

    showTable: 'Servicios'
        }
    }
    
    
}
</script>

<style>

</style>