<template>
    <div style="margin-bottom: 60px;">
        <b-navbar class="border-bottom sticky-top" toggleable="md" style="background-color: white !important;">
            <b-container>
                <b-navbar-brand href="/home">
                    <img src="../assets/CMCLogo.png" class="d-inline-block align-top" alt="Logo"
                        style="height: 50px;">
                </b-navbar-brand>
                <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>
                <b-collapse id="nav-collapse" is-nav>
                  
                </b-collapse>

                <div style="display: flex; flex-direction: row; align-items: center;">
                    <div style="margin-right: 20px;">
                        <label for="emergencies-number" style="font-size: smaller; color: red;">Línea de urgencias</label>
                        <p style="font-size: medium; font-weight: bold;" id="emergencies-number">(000) 123 45 67</p>
                    </div>

                    <!-- Barra de búsqueda -->
                    <b-form style="display: flex; flex-direction: row;" class="search-container">
                        <b-form-input variant="dark" type="text" placeholder="Buscar"
                            class="mr-sm-2 search-input"></b-form-input>
                        <b-icon icon="search" class="search-icon"></b-icon>
                    </b-form>

                    <router-link to="/admin">
                        <b-avatar style="margin-left: 20px;" variant="light" size="md" button id="avatar"></b-avatar>
                    </router-link>
                </div>

            </b-container>
        </b-navbar>
    </div>
</template>
<script>
export default {
    name: 'Nav'
}



</script>

<style >

.sticky-top {
    position: sticky;
    top: 0;
    z-index: 1000;
}

.search-container {
    position: relative;
}

.search-input {
    padding-right: 30px;
}

.search-icon {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
}
</style>
  