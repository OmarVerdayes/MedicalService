
<template>
    <div>

        <Nav class="sticky-top"></Nav>

        <b-container fluid>
            <b-row style="margin-inline: 200px; position: relative; z-index: 1;">
                <b-col style="display:flex;  flex-direction: column; justify-content: center;">
                    <h1 style="font-weight:900">Bienvenido a Cochis</h1>
                    <h4 style="font-weight:bold; color: rgb(90, 90, 90);">Servicio Médico</h4>
                    <h6 style="margin-top: 20px;">El único sistema integral de servicios de salud privada en México. 27
                        centros médicos a nivel nacional con los mejores especialistas y tecnología de punta. Más de 30 años
                        de experiencia en atención médica.</h6>
                </b-col>
                <b-col cols="7">
                    <img src="../assets/hands-medical-doctor.jpg" alt="logo"
                        style=" height: 100%; width: 100%; border-radius: 40px;">
                </b-col>

            </b-row>

            <b-row
                style="margin-inline: 20%; background-color: whitesmoke; padding: 24px; border-radius: 24px; margin-top: -40px; position: relative; z-index: 2;">
                <b-form style="display: flex; flex-direction: row; justify-content: space-between;">
                    <b-form-input type="text" placeholder="Buscar Doctor" style="margin-right: 16px;"></b-form-input>
                    <b-button variant="primary" type="sumbit"><b-icon icon="search"
                            style="margin: 4px; margin-inline: 10px;"></b-icon> </b-button>
                </b-form>

                <hr style="margin-top: 24px; margin-bottom: 24px;">

                <div style="display: flex; justify-content: center;">
                    <h6 style="font-weight: bold;">También puedes buscar</h6>
                </div>
                <div style="display: flex; flex-direction: row; justify-content: center; margin-top: 16px;">
                    <b-button variant="light" style="margin: 4px; margin-inline: 10px;" size="sm">Especialidad</b-button>
                    <b-button variant="light" style="margin: 4px; margin-inline: 10px;" size="sm">Médico</b-button>
                    <b-button variant="light" style="margin: 4px; margin-inline: 10px;" size="sm">Área</b-button>
                    <b-button variant="light" style="margin: 4px; margin-inline: 10px;" size="sm">Servicio</b-button>

                </div>
            </b-row>




            <swiper-container class="mySwiper" effect="coverflow" loop="true" autoplay-delay="3000"
                autoplay-pause-on-mouse-enter="true" autoplay="true" centered-slides="true" slides-per-view="auto"
                coverflow-effect-rotate="50" coverflow-effect-stretch="0" coverflow-effect-depth="100"
                coverflow-effect-modifier="1" coverflow-effect-slide-shadows="false">
                <swiper-slide id="sl1">
                    <img src="../assets/clinica-angeles1.jpg" @click="handleImageClick('clinica-angeles1.jpg')" />
                </swiper-slide>
                <swiper-slide>
                    <img src="../assets/clinica-angeles2.jpg" @click="handleImageClick('clinica-angeles2.jpg')" />
                </swiper-slide>
                <swiper-slide>
                    <img src="../assets/clinica-angeles3.jpg" @click="handleImageClick('clinica-angeles3.jpg')" />
                </swiper-slide>
                <swiper-slide>
                    <img src="../assets/clinica-angeles4.jpg" @click="handleImageClick('clinica-angeles4.jpg')" />
                </swiper-slide>
            </swiper-container>


        </b-container>
    </div>
</template>


<script>
import Nav from '../components/Nav.vue'
export default {
    name: 'Home',
    components: {
        Nav,
    },
    methods: {
        handleImageClick(imageSrc) {
            console.log("Imagen clickeada:", imageSrc);
        }
    }
};

</script>

<style>
swiper-container {
    width: 100%;
    padding-top: 50px;
    padding-bottom: 50px;
}

swiper-slide {
    background-position: center;
    background-size: cover;
    width: 700px;
    height: auto;
    cursor: pointer;
}

swiper-slide img {
    display: block;
    width: 100%;
}
</style>