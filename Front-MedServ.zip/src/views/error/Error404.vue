<template>
    <div><h1>Error 404</h1>
    <h1>Pagina no encontrada </h1></div>
    
</template>

<script>
export default {}
</script>

<style>

</style>