<template>
    <div>
        <Nav class="sticky-top"></Nav>
        <div class="admin"> 
            <UserInfo @sendData="setTabInfo"/>
        </div>
<!-- Seleccion de informacionn de Doctores, pacientes, especialidades y servicios -->
        <div class="flexContainer" v-if="tabInfo === 'Admin'">
            <b-container fluid="lg"> 

                <!-- Botones carpetas -->
                <b-row >
                    <b-col  v-for="(card, index) in cards" :key="index" >
                        <b-card 
                        class="cards col"  
                        :id="'card-' + index"
                        @mouseover="hoveredIndex = index"
                        @mouseleave="hoveredIndex = null"   
                        :class="{ 'bg-hover': hoveredIndex === index }"
                        @click="navigate(card)"
                        style="cursor: pointer;"
                        >
                        <b-row no-glutters>
                            <b-col no-glutters><b-icon icon="folder-fill" variant="warning" font-scale="4"></b-icon></b-col>
                            <b-col no-glutters><b-text style="font-size: 1.3epm ;">{{ card }}</b-text></b-col>
                        </b-row>
        
                        </b-card>
                    </b-col>
                </b-row>

                <!-- Filtros busqueda -->
                <b-row class="text-center justify-content-center mb-4 "> 
                    <div style="padding: 15px; border-radius: 15px; background-color: aqua;" class="w-50 w-sm-60" >
                        <b-row >
                            <b-col cols="8" >             
                                    <b-form-input v-model="searchTerm" placeholder="Buscar Nombre Médico"></b-form-input>
                            </b-col>
                            <b-col cols="auto" >
                                <b-button size="md" variant="primary" class="mb-2">
                                <b-icon icon="search" aria-label="Help"></b-icon>
                                </b-button>
                            </b-col>
                            <b-col  cols="auto">
                                <b-dropdown variant="primary">
                                    <template #button-content>
                                        <b-icon icon="sliders" aria-hidden="true"></b-icon> Filtros
                                    </template>
                                    <b-dropdown-item-button value="name ">Nombre</b-dropdown-item-button>
                                    <b-dropdown-item-button>Especialidad</b-dropdown-item-button>
                                    <b-dropdown-item-button>Cédula</b-dropdown-item-button>
                                    <b-dropdown-item-button>Correo</b-dropdown-item-button>
                                    <b-dropdown-divider></b-dropdown-divider>
                                    <b-dropdown-item-button variant="danger">
                                        <b-icon icon="trash-fill" aria-hidden="true"></b-icon>
                                        Delete
                                    </b-dropdown-item-button>
                                </b-dropdown>
                            </b-col>
                        </b-row>
                </div>
                    
                </b-row>

                
                <b-row><router-view></router-view></b-row>         
            </b-container>

        
        </div>

<!-- Crear y administrar paquetes -->
        <b-container v-if="tabInfo === 'Paquetes'">
           
        </b-container>

<!-- Administrar las citas generales -->
        <b-container v-if="tabInfo === 'Citas'">
            <FullCalendarDoctor/>
        </b-container>

        
    </div>
</template>

<script>

import Nav from '../components/Nav.vue';
import UserInfo from '../components/userComponents/UserInfo.vue';
import FullCalendarDoctor from '../components/userComponents/FullCalendarDoctor.vue';


export default {
    components: {
        FullCalendarDoctor,
        Nav,
        UserInfo,
      
    },
    data(){
        return{
            cards:["Doctores", "Pacientes" ,"Servicios"],
            isHovered: false,
            tabInfo: "Admin",
            searchTerm: ''       
        }
        
    },
    methods:{


        onDrag(evt, item) {
            evt.dataTransfer.dropEffect = "move";
            evt.dataTransfer.effectAllowed = "move";
            evt.dataTransfer.setData("formData", JSON.stringify(item));
            
        },

        handleHover(event){
            this.isHovered = event;
        },

        navigate(cardInfo){
            console.log(cardInfo)
            this.$router.push({
            name: "admin",
        });
            this.$router.push({
            name: "adminCards",
            params: {
              tableInfo: cardInfo,
            },
        });
        },

        setTabInfo(data){
            
            this.tabInfo = data;
           
        }


    }
}
</script>
<style >

.admin{
    display: flex;
    justify-content: center;
    flex-wrap: wrap; 
}
.flexContainer{
    background-color: rgb(241, 241, 241);     

  
}

.bg-hover{
    background-color: rgba(0, 38, 164, 0.574);
    color: white;
    transition: background-color 0.4s ease, color 0.4s ease; /* Combina ambas transiciones en una sola declaración */
}
.cards{
    transition: background-color 0.4s ease, color 0.4s ease;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    margin: 20px;
}
.tableContainer{
    justify-content: center;
    width: 70%;
    background-color: white;
    overflow: hidden;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}

</style>