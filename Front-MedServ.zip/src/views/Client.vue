<template>
  <div>
    <Nav class="sticky-top"></Nav>
    <div class="client">
      <UserInfo @sendData="setTabInfo"/>
    </div>
    <div class="flexContainer">
      <div>
        <!-- Aquí se renderiza el modal si tabInfo es "Generar Cita" -->
        <b-modal v-if="tabInfo === 'Generar Cita'" ref="modal" title="Generar Cita" 
          hide-footer
          size="lg"
          modal-class="custom-modal"
          header-bg-variant="success"
    >
      <b-form
        @submit.prevent="onSubmit"
        enctype="multipart/form-data"
        class="modal-form"
      >
        <b-row>
          <b-col cols="6">
            <b-form-group label="Nombre">
              <b-form-input
                v-validate="'required|alpha_spaces|min:3'"
                name="names"
                v-model="user.names"
                type="text"
              />
              <span class="text-danger">{{ errors.first("names") }}</span>
            </b-form-group>
          </b-col>
          <b-col cols="6">
            <b-form-group label="Apellidos">
              <b-form-input
                v-validate="'required|alpha_spaces|min:3'"
                name="lastName"
                v-model="user.lastName"
                type="text"
              />
              <span class="text-danger">{{ errors.first("lastName") }}</span>
            </b-form-group>
          </b-col>
        </b-row>

        <b-row>
          <b-col cols="6">
            <b-form-group label="username">
              <b-form-input
                v-validate="'required|alpha_num'"
                name="username"
                v-model="user.username"
                type="text"
              />
              <span class="text-danger">{{ errors.first("username") }}</span>
            </b-form-group>
          </b-col>

          <b-col cols="6">
            <b-form-group label="role">
              <b-form-select
                v-validate="'required'"
                name="role"
                v-model="user.role"
              >
                <option value="">Seleccionar rol</option>
                <option value="ROLE_USER">Usuario</option>
                <option value="ROLE_USER">Arrendador</option>
              </b-form-select>
              <span class="text-danger">{{ errors.first("role") }}</span>
            </b-form-group>
          </b-col>
        </b-row>

        <b-row>
          <b-col cols="12">
            <b-form-group label="address">
              <b-form-input
                v-validate="'required|regex:^[a-zA-Z0-9 #]+$'"
                name="address"
                v-model="user.address"
                type="text"
              />
              <span class="text-danger">{{ errors.first("address") }}</span>
            </b-form-group>
          </b-col>
        </b-row>

        <b-row>
          <b-col cols="6">
            <b-form-group label="date">
              <b-form-datepicker
                v-validate="'required|adult'"
                name="date"
                v-model="user.date"
                type="text"
              />
              <span class="text-danger">{{ errors.first("date") }}</span>
            </b-form-group>
          </b-col>
          <b-col cols="6">
            <b-form-group label="phone">
              <b-form-input
                v-validate="'required|digits:10'"
                name="phone"
                v-model="user.phone"
                type="text"
              />
              <span class="text-danger">{{ errors.first("phone") }}</span>
            </b-form-group>
          </b-col>
        </b-row>

        <b-row>
          <b-col cols="6">
            <b-form-group label="gender">
              <b-form-select
                v-validate="'required'"
                name="gender"
                v-model="user.gender"
              >
                <option value="">Seleccionar Género</option>
                <option value="masculino">Masculino</option>
                <option value="femenino">Femenino</option>
              </b-form-select>
              <span class="text-danger">{{ errors.first("gender") }}</span>
            </b-form-group>
          </b-col>

          <b-col cols="6">
            <b-form-group label="profilePicture">
              <b-form-file
                v-validate="'required|imageSize'"
                name="profilePicture"
                v-model="user.profilePicture"
                :state="Boolean(user.profilePicture)"
                placeholder="Seleccione una imagen"
                accept="image/*"
              >
              </b-form-file>
              <span class="text-danger">{{
                errors.first("profilePicture")
              }}</span>
            </b-form-group>
          </b-col>
        </b-row>
        <b-row>
          <b-col cols="6">
            <b-form-group label="email">
              <b-form-input
                v-validate="'required|email'"
                name="email"
                v-model="user.email"
                type="email"
              />
              <span class="text-danger">{{ errors.first("email") }}</span>
            </b-form-group>
          </b-col>
          <b-col cols="6">
            <b-form-group label="password">
              <b-form-input
                v-validate="'required|min:8|specialCharacter|noSpace'"
                name="password"
                v-model="user.password"
                type="password"
                :class="{ 'is-danger': errors.has('password') }"
                ref="password"
              />
              <span class="text-danger">{{ errors.first("password") }}</span>
            </b-form-group>
          </b-col>
        </b-row>

        <!-- Botón Enviar -->
        <div class="text-center">
          <b-button style="margin-top: 5%" type="submit" variant="primary"
            >Enviar</b-button
          >
        </div>
      </b-form>
    </b-modal>
      </div>
  
</div>
</div>
</template>

<script>
import UserInfo from '../components/userComponents/UserInfo.vue';
import Nav from '../components/Nav.vue';

export default {
  components: {
  UserInfo,
  Nav
  },
  data() {
    return {
      tabInfo: null,
      formData: {
        name: '',
        date: ''
        // Otros campos del formulario
      },
      chooseDoctor: 'no',
      specialities: ['Cardiología', 'Dermatología', 'Pediatría', 'Ginecología', 'Oftalmología'],
      doctors: ['Dr. Juan Pérez', 'Dra. María González', 'Dr. Carlos López', 'Dra. Ana Martínez', 'Dr. José Sánchez'],
      selectedSpeciality: '',
      selectedDoctor: '',
      selectedTime: '',
      selectedDate: ''
    };
  },
  methods:{
  
    setTabInfo(data){
            this.tabInfo = data;
            console.log(data+" la data")
            if (this.tabInfo === 'Generar Cita') {
        this.$nextTick(() => {
          this.$refs.modal.show();
        });
      }
    },
    submitForm() {
      // Aquí puedes agregar la lógica para enviar el formulario
      // Por ejemplo, hacer una solicitud HTTP para generar la cita
      console.log('Formulario enviado');
      
      // Limpia los datos del formulario después de enviarlo
      this.formData.name = '';
      this.formData.date = '';
      // Limpia otros campos del formulario si los hubiera
      
      // Cierra el modal después de enviar el formulario
      this.$refs.modal.hide();
    }
  }
  
};
</script>

<style>
.flexContainer{
  background-color: rgb(241, 241, 241);

}




</style>