<template>
  <div>
    <Nav class="sticky-top"></Nav>
    <div class="doctor">
      <UserInfo @sendData="setTabInfo"/>
    </div>
  
   <b-container fluid class="flexContainer">
    <b-row align-h="center" >

      <b-col md="9"  class=" text-center">
        <FullCalendarDoctor></FullCalendarDoctor>
      <!-- <VCalendar is-expanded style="min-width: 85%; min-height: 60%;"></VCalendar> -->

      <b-row style="background-color: blueviolet;" class="mt-4">
        
      </b-row>
      </b-col>
      <!-- Area de comentarios -->
      <b-col cols-md="2" class="comments " v-if="tabInfo === 'Comentarios'">
        <b-row><h3>Comentarios Generales</h3></b-row>
        <b-row  v-for="(comment,index) in comments" :key="index"><b-card no-body class="comment">{{ comment }}</b-card></b-row> 
      </b-col>

      <!-- Citas Pendientes de confirmación -->

      <b-col cols-md="2" class="comments" v-if="tabInfo === 'Citas Pendientes'"> 
      <h1>Citas Pendientes</h1>
      <b-table striped hover :items="pendingAppointments" :fields="fields">
        <template v-slot:cell(Estatus)="row">
          <b-button @click="openModal(row.item)" class="sm" variant="primary">{{ row.item.Estatus }}</b-button>
        </template>
      </b-table>
    </b-col>

    <!-- Modal para mostrar detalles de la cita -->
    <b-modal ref="modal" title="Detalles de la Cita">
      <h1>Alas</h1>
    </b-modal>


    </b-row>

    

</b-container>
    


  </div>
</template>

<script>
import UserInfo from '../components/userComponents/UserInfo.vue';
import FullCalendarDoctor from '../components/userComponents/FullCalendarDoctor.vue';
import Nav from '../components/Nav.vue';
import VCalendar from '../components/userComponents/VCalendar.vue';

export default {
  components: {
  FullCalendarDoctor,
  VCalendar,
  UserInfo,
  Nav
  },
  data(){
    return{
      comments:["asbdja asd","asda asd sad", "asdad asda asd as dd","asbdja asd","asda asd sad", "asdad asda asd as dd","asbdja asd","asda asd sad", "asdad asda asd as dd", "asg asda daw awdadw wada adw","asdhaskd askdhasjkdhasm bdas dhaskjdfbas daksjhdaksjbdaksdluas","asjdhaks ashdbam asghdkas djahsgbdjkas djha", "askbgdajskh fkasbdfkhasd asdbnaksjd asdhkbasdm jhasbdmas dkjahsbd"],
      tabInfo:'',
      doctorInfo: {
        name: 'Zuriel',
        specialty: 'Cardio',
        rating:'6'
      },
      searchItem:'',
      pendingAppointments: [
      { Paciente: 'Juan Pérez',  Fecha: '2024-03-15', Estatus: 'Pendiente',  },
      { Paciente: 'María González',  Fecha: '2024-03-16', Estatus: 'Pendiente'},
      { Paciente: 'Luisa Martínez', Fecha: '2024-03-17', Estatus: 'Pendiente'},
      { Paciente: 'Carlos Sánchez',  Fecha: '2024-03-18', Estatus: 'Pendiente' },
      { Paciente: 'Ana Ramírez',  Fecha: '2024-03-19', Estatus: 'Pendiente' },
      { Paciente: 'Pedro Rodríguez', Fecha: '2024-03-20', Estatus: 'Pendiente'}
    
      ]
    }
  },
  methods:{
    setTabInfo(data){
            this.tabInfo = data;
        },
        openModal(appointment) {
      // Abre el modal y muestra los detalles de la cita
      this.$refs.modal.show();
      console.log(appointment); // Puedes mostrar los detalles de la cita en el modal
    }
  }
}
</script>

<style>
.flexContainer{
  background-color: rgb(241, 241, 241);
  padding: 20px;
}
.doctor{
    display: flex;
    justify-content: center;
    flex-wrap: wrap; 
}
.confirm-button {
  background-color: rgb(103, 189, 103);
  color: white;
  font-size: 20px;
  height: 80px;
  padding: 15px 30px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
}

.cancel-button {
  background-color: rgb(215, 101, 101);
  color: white;
  font-size: 20px;
  height: 80px;
  padding: 15px 30px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
}

.comments{
  padding: 25px;
  max-height: 600px ;
  overflow: scroll;
  background-color: rgb(251, 253, 255);
  border-radius: 10px;
  border: solid rgb(219, 219, 219);
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.108);
}
.comment{
 
  margin-top:10px;
  background-color: rgba(224, 224, 224, 0.749);
  border: rgba(0, 0, 0, 0);
  padding: 15px;
  border-radius: 13px;
  min-width: 200px;
  min-height: 50px;
  max-width: 90%;
  word-wrap: break-word;
}

</style>