import VueRouter from "vue-router";
import Vue from "vue";

Vue.use(VueRouter);

const routes = [
    {
        path: '/',
        redirect: '/home'
    },
    {
        path: '*',
        component: () => import('../views/error/Error404.vue')
    },
    {
        path : "/admin",
        name : 'admin',
        component : () => import('../views/Admin.vue'),
        children: [
            {
                path: '/adminTable',
                name: 'adminTable',
                component: () => import('../components/userComponents/Table.vue'),
                props:true
            },
            {
                path: '/adminCards',
                name: 'adminCards',
                component: () => import('../components/userComponents/CardInfo.vue'),
                props:true
            },
        ]
    },
    {
        path : "/doctor",
        name : 'doctor',
        component : () => import('../views/Doctor.vue')
    },
    {
        path: "/client",
        name: 'client',
        component : () => import('../views/Client.vue')
    },
    {
        path: '/home',
        name : 'home',
        component : () => import('../views/Home.vue'),
        children: [

            {
                path: '/login',
                name: 'login',
                component: () => import('../views/Login.vue')
            },
        ]
    }
]

const router = new VueRouter({ routes, })
export default router;